const { Pool } = require('pg');

const connectionString = process.env.DATABASE_URL || 'postgres://cv:cv@localhost:5432/contentverse';
const needsSSL = /neon\.tech|render\.com|sslmode=require/.test(connectionString);

const pool = new Pool({
  connectionString,
  ssl: needsSSL ? { rejectUnauthorized: false } : false,
  max: 5,
});

const q = (text, params) => pool.query(text, params);

const DEFAULT_CATEGORIES = [
  ['Furniture', 'furniture', 'Sofas, beds, tables and smart furniture ideas.', '#c2703d'],
  ['Home & Decor', 'home-decor', 'Interior styling, decor trends and DIY makeovers.', '#d64f7a'],
  ['Health', 'health', 'Wellness, nutrition and everyday health tips.', '#2f9e6e'],
  ['Fitness', 'fitness', 'Workouts, training plans and active living.', '#ff6a3d'],
  ['Electronics', 'electronics', 'Gadgets, reviews and buying guides.', '#4f5bd5'],
];

const DEFAULT_SETTINGS = {
  site_title: 'Content Verse',
  tagline: 'Stories on living better — home, health, fitness & tech.',
  head_code: '',
  require_approval: '1',
  allow_registration: '1',
  footer_text: 'A universe of useful stories, written by people like you.',
};

async function init() {
  await q(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'author',
      bio TEXT DEFAULT '',
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS categories (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT DEFAULT '',
      color TEXT DEFAULT '#6c4cff',
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS articles (
      id SERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      excerpt TEXT DEFAULT '',
      content TEXT DEFAULT '',
      featured_image TEXT DEFAULT '',
      category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
      author_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'draft',
      tags TEXT DEFAULT '',
      meta_title TEXT DEFAULT '',
      meta_description TEXT DEFAULT '',
      views INTEGER DEFAULT 0,
      published_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status, published_at DESC);
    CREATE TABLE IF NOT EXISTS media (
      id SERIAL PRIMARY KEY,
      filename TEXT,
      mime TEXT NOT NULL,
      data BYTEA NOT NULL,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT DEFAULT ''
    );
  `);

  const { rows } = await q('SELECT COUNT(*)::int AS n FROM categories');
  if (rows[0].n === 0) {
    for (const c of DEFAULT_CATEGORIES) {
      await q('INSERT INTO categories(name, slug, description, color) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING', c);
    }
  }
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    await q('INSERT INTO settings(key, value) VALUES ($1,$2) ON CONFLICT (key) DO NOTHING', [k, v]);
  }
}

async function getSettings() {
  const { rows } = await q('SELECT key, value FROM settings');
  const s = { ...DEFAULT_SETTINGS };
  rows.forEach((r) => (s[r.key] = r.value));
  return s;
}

module.exports = { pool, q, init, getSettings };
