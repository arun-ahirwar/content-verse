const router = require('express').Router();
const multer = require('multer');
const bcrypt = require('bcryptjs');
const db = require('../db');
const h = require('../lib/helpers');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 4 * 1024 * 1024 },
  fileFilter: (req, file, cb) => cb(null, /^image\/(png|jpe?g|gif|webp|svg\+xml|avif)$/.test(file.mimetype)),
});

function flash(req, type, msg) { req.session.flash = { type, msg }; }

const requireLogin = (req, res, next) => (req.user ? next() : res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`));
const requireAdmin = (req, res, next) => (req.user && req.user.role === 'admin' ? next() : res.status(403).render('admin/denied', { title: 'Not allowed' }));

router.use(requireLogin);
router.use((req, res, next) => { res.locals.isAdmin = req.user.role === 'admin'; next(); });

async function loadOwnArticle(req, res) {
  const { rows } = await db.q('SELECT * FROM articles WHERE id=$1', [parseInt(req.params.id, 10) || 0]);
  const a = rows[0];
  if (!a || (req.user.role !== 'admin' && a.author_id !== req.user.id)) return null;
  return a;
}

// ---------- Dashboard ----------
router.get('/', async (req, res, next) => {
  try {
    const mine = req.user.role === 'admin' ? '' : 'WHERE author_id=$1';
    const params = req.user.role === 'admin' ? [] : [req.user.id];
    const stats = await db.q(`SELECT
      COUNT(*) FILTER (WHERE status='published')::int AS published,
      COUNT(*) FILTER (WHERE status='draft')::int AS draft,
      COUNT(*) FILTER (WHERE status='pending')::int AS pending,
      COALESCE(SUM(views),0)::int AS views FROM articles ${mine}`, params);
    const recent = await db.q(`SELECT a.id, a.title, a.slug, a.status, a.updated_at, u.name AS author_name, c.name AS cat_name
      FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN categories c ON c.id=a.category_id
      ${mine.replace('author_id', 'a.author_id')} ORDER BY a.updated_at DESC LIMIT 8`, params);
    const users = req.user.role === 'admin' ? (await db.q('SELECT COUNT(*)::int AS n FROM users')).rows[0].n : null;
    res.render('admin/dashboard', { title: 'Dashboard', stats: stats.rows[0], recent: recent.rows, usersCount: users });
  } catch (e) { next(e); }
});

// ---------- Articles ----------
router.get('/articles', async (req, res, next) => {
  try {
    const status = ['published', 'draft', 'pending'].includes(req.query.status) ? req.query.status : '';
    const term = String(req.query.q || '').trim();
    const where = []; const params = [];
    if (req.user.role !== 'admin') { params.push(req.user.id); where.push(`a.author_id=$${params.length}`); }
    const countParams = [...params];
    const countWhere = where.length ? `WHERE ${where.join(' AND ')}` : '';
    if (status) { params.push(status); where.push(`a.status=$${params.length}`); }
    if (term) { params.push(`%${term}%`); where.push(`a.title ILIKE $${params.length}`); }
    const { rows } = await db.q(`SELECT a.id, a.title, a.slug, a.status, a.views, a.updated_at, a.published_at, u.name AS author_name, c.name AS cat_name, c.color AS cat_color
      FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN categories c ON c.id=a.category_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY a.updated_at DESC LIMIT 300`, params);
    const counts = await db.q(`SELECT status, COUNT(*)::int AS n FROM articles a ${countWhere} GROUP BY status`, countParams);
    const c = { all: 0, published: 0, draft: 0, pending: 0 };
    counts.rows.forEach((r) => { c[r.status] = r.n; c.all += r.n; });
    res.render('admin/articles', { title: 'Articles', articles: rows, status, term, counts: c });
  } catch (e) { next(e); }
});

router.get('/articles/new', (req, res) => {
  res.render('admin/editor', { title: 'Add New Article', a: { id: null, title: '', content: '', excerpt: '', featured_image: '', category_id: null, tags: '', meta_title: '', meta_description: '', status: 'draft', slug: '' } });
});

router.get('/articles/:id/edit', async (req, res, next) => {
  try {
    const a = await loadOwnArticle(req, res);
    if (!a) return next();
    res.render('admin/editor', { title: 'Edit Article', a });
  } catch (e) { next(e); }
});

async function saveArticle(req, res, existing) {
  const b = req.body;
  const isAdmin = req.user.role === 'admin';
  const title = String(b.title || '').trim().slice(0, 200) || 'Untitled';
  const content = h.cleanContent(b.content);
  const excerpt = String(b.excerpt || '').trim().slice(0, 400) || h.makeExcerpt(content);
  const catId = parseInt(b.category_id, 10) || null;
  const featured = /^(\/media\/\d+|https?:\/\/[^\s"'<>]+)$/.test(String(b.featured_image || '').trim()) ? String(b.featured_image).trim() : '';
  const tags = String(b.tags || '').split(',').map((t) => t.trim()).filter(Boolean).slice(0, 15).join(', ');
  const metaTitle = String(b.meta_title || '').trim().slice(0, 120);
  const metaDesc = String(b.meta_description || '').trim().slice(0, 300);

  // Work out the requested status
  let status = 'draft';
  if (b.action === 'publish') {
    status = (isAdmin || res.locals.settings.require_approval !== '1') ? 'published' : 'pending';
  } else if (b.action === 'update' && existing) {
    status = existing.status === 'published' && !isAdmin && res.locals.settings.require_approval === '1' ? 'pending' : existing.status;
  }
  const slugInput = String(b.slug || '').trim();
  const slug = await h.uniqueSlug('articles', slugInput || title, existing ? existing.id : null);

  if (existing) {
    const publishedAt = status === 'published' ? (existing.published_at || new Date()) : existing.published_at;
    await db.q(`UPDATE articles SET title=$1, slug=$2, excerpt=$3, content=$4, featured_image=$5, category_id=$6, tags=$7,
      meta_title=$8, meta_description=$9, status=$10, published_at=$11, updated_at=now() WHERE id=$12`,
    [title, slug, excerpt, content, featured, catId, tags, metaTitle, metaDesc, status, publishedAt, existing.id]);
    return { id: existing.id, status, slug };
  }
  const { rows } = await db.q(`INSERT INTO articles(title, slug, excerpt, content, featured_image, category_id, tags, meta_title, meta_description, status, author_id, published_at)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
  [title, slug, excerpt, content, featured, catId, tags, metaTitle, metaDesc, status, req.user.id, status === 'published' ? new Date() : null]);
  return { id: rows[0].id, status, slug };
}

const statusMsg = { published: 'Article published! It is now live on the website.', pending: 'Article submitted for review. An admin will publish it soon.', draft: 'Draft saved.' };

router.post('/articles', async (req, res, next) => {
  try {
    const r = await saveArticle(req, res, null);
    flash(req, 'success', statusMsg[r.status]);
    res.redirect(`/admin/articles/${r.id}/edit`);
  } catch (e) { next(e); }
});

router.post('/articles/:id', async (req, res, next) => {
  try {
    const a = await loadOwnArticle(req, res);
    if (!a) return next();
    const r = await saveArticle(req, res, a);
    flash(req, 'success', req.body.action === 'update' ? 'Article updated.' : statusMsg[r.status]);
    res.redirect(`/admin/articles/${r.id}/edit`);
  } catch (e) { next(e); }
});

router.post('/articles/:id/status', requireAdmin, async (req, res, next) => {
  try {
    const status = ['published', 'draft', 'pending'].includes(req.body.status) ? req.body.status : 'draft';
    await db.q(`UPDATE articles SET status=$1, published_at=CASE WHEN $1='published' THEN COALESCE(published_at, now()) ELSE published_at END, updated_at=now() WHERE id=$2`, [status, parseInt(req.params.id, 10) || 0]);
    flash(req, 'success', `Article marked as ${status}.`);
    res.redirect(req.get('referer') && req.get('referer').includes('/admin') ? req.get('referer') : '/admin/articles');
  } catch (e) { next(e); }
});

router.post('/articles/:id/delete', async (req, res, next) => {
  try {
    const a = await loadOwnArticle(req, res);
    if (!a) return next();
    await db.q('DELETE FROM articles WHERE id=$1', [a.id]);
    flash(req, 'success', 'Article deleted.');
    res.redirect('/admin/articles');
  } catch (e) { next(e); }
});

// ---------- Media upload (TinyMCE + featured image) ----------
router.post('/upload', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Please upload an image (JPG, PNG, GIF, WEBP) under 4 MB.' });
    if (req.file.mimetype === 'image/svg+xml') return res.status(400).json({ error: 'SVG files are not allowed.' });
    const { rows } = await db.q('INSERT INTO media(filename, mime, data, user_id) VALUES ($1,$2,$3,$4) RETURNING id', [req.file.originalname, req.file.mimetype, req.file.buffer, req.user.id]);
    res.json({ location: `/media/${rows[0].id}` });
  } catch (e) { next(e); }
});

// ---------- Categories (admin) ----------
router.get('/categories', requireAdmin, (req, res) => {
  res.render('admin/categories', { title: 'Categories', edit: res.locals.categories.find((c) => String(c.id) === req.query.edit) || null });
});

router.post('/categories', requireAdmin, async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim().slice(0, 60);
    if (!name) { flash(req, 'error', 'Category name is required.'); return res.redirect('/admin/categories'); }
    const color = /^#[0-9a-f]{6}$/i.test(req.body.color) ? req.body.color : '#6c4cff';
    const desc = String(req.body.description || '').trim().slice(0, 300);
    const id = parseInt(req.body.id, 10) || null;
    const slug = await h.uniqueSlug('categories', String(req.body.slug || '').trim() || name, id);
    if (id) await db.q('UPDATE categories SET name=$1, slug=$2, description=$3, color=$4 WHERE id=$5', [name, slug, desc, color, id]);
    else await db.q('INSERT INTO categories(name, slug, description, color) VALUES ($1,$2,$3,$4)', [name, slug, desc, color]);
    flash(req, 'success', id ? 'Category updated.' : `Category “${name}” added.`);
    res.redirect('/admin/categories');
  } catch (e) { next(e); }
});

router.post('/categories/:id/delete', requireAdmin, async (req, res, next) => {
  try {
    await db.q('DELETE FROM categories WHERE id=$1', [parseInt(req.params.id, 10) || 0]);
    flash(req, 'success', 'Category deleted. Its articles are now uncategorized.');
    res.redirect('/admin/categories');
  } catch (e) { next(e); }
});

// ---------- Users (admin) ----------
router.get('/users', requireAdmin, async (req, res, next) => {
  try {
    const { rows } = await db.q(`SELECT u.id, u.name, u.email, u.role, u.created_at, COUNT(a.id)::int AS posts
      FROM users u LEFT JOIN articles a ON a.author_id=u.id GROUP BY u.id ORDER BY u.created_at DESC`);
    res.render('admin/users', { title: 'Users', users: rows });
  } catch (e) { next(e); }
});

router.post('/users/:id/role', requireAdmin, async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10) || 0;
    if (id === req.user.id) { flash(req, 'error', 'You cannot change your own role.'); return res.redirect('/admin/users'); }
    const role = req.body.role === 'admin' ? 'admin' : 'author';
    await db.q('UPDATE users SET role=$1 WHERE id=$2', [role, id]);
    flash(req, 'success', 'Role updated.');
    res.redirect('/admin/users');
  } catch (e) { next(e); }
});

router.post('/users/:id/delete', requireAdmin, async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10) || 0;
    if (id === req.user.id) { flash(req, 'error', 'You cannot delete yourself.'); return res.redirect('/admin/users'); }
    await db.q('DELETE FROM users WHERE id=$1', [id]);
    flash(req, 'success', 'User and their articles deleted.');
    res.redirect('/admin/users');
  } catch (e) { next(e); }
});

// ---------- Settings (admin) ----------
router.get('/settings', requireAdmin, (req, res) => res.render('admin/settings', { title: 'Settings' }));

router.post('/settings', requireAdmin, async (req, res, next) => {
  try {
    const b = req.body;
    const vals = {
      site_title: String(b.site_title || 'Content Verse').slice(0, 80),
      tagline: String(b.tagline || '').slice(0, 200),
      footer_text: String(b.footer_text || '').slice(0, 300),
      head_code: String(b.head_code || '').slice(0, 5000),
      require_approval: b.require_approval ? '1' : '0',
      allow_registration: b.allow_registration ? '1' : '0',
    };
    for (const [k, v] of Object.entries(vals)) {
      await db.q('INSERT INTO settings(key, value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value', [k, v]);
    }
    flash(req, 'success', 'Settings saved.');
    res.redirect('/admin/settings');
  } catch (e) { next(e); }
});

// ---------- Profile ----------
router.get('/profile', (req, res) => res.render('admin/profile', { title: 'Your Profile' }));

router.post('/profile', async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim().slice(0, 80) || req.user.name;
    const bio = String(req.body.bio || '').trim().slice(0, 500);
    await db.q('UPDATE users SET name=$1, bio=$2 WHERE id=$3', [name, bio, req.user.id]);
    if (req.body.new_password) {
      const { rows } = await db.q('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
      if (!(await bcrypt.compare(String(req.body.current_password || ''), rows[0].password_hash))) {
        flash(req, 'error', 'Current password is incorrect. Profile saved, password not changed.');
        return res.redirect('/admin/profile');
      }
      if (String(req.body.new_password).length < 8) {
        flash(req, 'error', 'New password must be at least 8 characters.');
        return res.redirect('/admin/profile');
      }
      await db.q('UPDATE users SET password_hash=$1 WHERE id=$2', [await bcrypt.hash(String(req.body.new_password), 10), req.user.id]);
    }
    flash(req, 'success', 'Profile updated.');
    res.redirect('/admin/profile');
  } catch (e) { next(e); }
});

module.exports = router;
