const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');

const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'arun.ahirwar.online@gmail.com').toLowerCase();

function flash(req, type, msg) { req.session.flash = { type, msg }; }

router.get('/login', (req, res) => {
  if (req.user) return res.redirect('/admin');
  res.render('auth', { title: 'Log in', mode: 'login', next: req.query.next || '' });
});

router.post('/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const { rows } = await db.q('SELECT * FROM users WHERE email=$1', [email]);
    const u = rows[0];
    if (!u || !(await bcrypt.compare(String(req.body.password || ''), u.password_hash))) {
      flash(req, 'error', 'Email or password is incorrect.');
      return res.redirect('/login');
    }
    if (email === ADMIN_EMAIL && u.role !== 'admin') await db.q("UPDATE users SET role='admin' WHERE id=$1", [u.id]);
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = u.id;
      const dest = String(req.body.next || '');
      res.redirect(dest.startsWith('/') && !dest.startsWith('//') ? dest : '/admin');
    });
  } catch (e) { next(e); }
});

router.get('/register', (req, res) => {
  if (req.user) return res.redirect('/admin');
  if (res.locals.settings.allow_registration !== '1') {
    flash(req, 'error', 'New registrations are currently closed.');
    return res.redirect('/login');
  }
  res.render('auth', { title: 'Create account', mode: 'register', next: '' });
});

router.post('/register', async (req, res, next) => {
  try {
    if (res.locals.settings.allow_registration !== '1') return res.redirect('/login');
    const name = String(req.body.name || '').trim().slice(0, 80);
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8) {
      flash(req, 'error', 'Please enter your name, a valid email and a password of at least 8 characters.');
      return res.redirect('/register');
    }
    const exists = await db.q('SELECT id FROM users WHERE email=$1', [email]);
    if (exists.rows.length) {
      flash(req, 'error', 'An account with this email already exists. Please log in.');
      return res.redirect('/login');
    }
    const hash = await bcrypt.hash(password, 10);
    const role = email === ADMIN_EMAIL ? 'admin' : 'author';
    const { rows } = await db.q('INSERT INTO users(name, email, password_hash, role) VALUES ($1,$2,$3,$4) RETURNING id', [name, email, hash, role]);
    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = rows[0].id;
      req.session.flash = { type: 'success', msg: `Welcome to Content Verse, ${name}! Start writing your first article.` };
      res.redirect('/admin');
    });
  } catch (e) { next(e); }
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

module.exports = router;
