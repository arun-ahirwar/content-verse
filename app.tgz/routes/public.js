const router = require('express').Router();
const db = require('../db');

const PER_PAGE = 9;
const BASE_SELECT = `SELECT a.id, a.title, a.slug, a.excerpt, a.featured_image, a.published_at, a.content, a.views,
  c.name AS cat_name, c.slug AS cat_slug, c.color AS cat_color, u.name AS author_name, u.id AS author_id
  FROM articles a LEFT JOIN categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id`;

async function listArticles(where, params, page) {
  const offset = (page - 1) * PER_PAGE;
  const total = await db.q(`SELECT COUNT(*)::int AS n FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.status='published' ${where}`, params);
  const { rows } = await db.q(`${BASE_SELECT} WHERE a.status='published' ${where}
    ORDER BY a.published_at DESC LIMIT ${PER_PAGE} OFFSET ${offset}`, params);
  return { articles: rows, page, pages: Math.max(1, Math.ceil(total.rows[0].n / PER_PAGE)), total: total.rows[0].n };
}

const pageNum = (req) => Math.max(1, parseInt(req.query.page, 10) || 1);

router.get('/', async (req, res, next) => {
  try {
    const page = pageNum(req);
    const data = await listArticles('', [], page);
    const popular = await db.q(`${BASE_SELECT} WHERE a.status='published' ORDER BY a.views DESC, a.published_at DESC LIMIT 5`);
    res.render('home', { title: null, ...data, popular: popular.rows, basePath: '/' });
  } catch (e) { next(e); }
});

router.get('/category/:slug', async (req, res, next) => {
  try {
    const cat = res.locals.categories.find((c) => c.slug === req.params.slug);
    if (!cat) return next();
    const data = await listArticles('AND a.category_id=$1', [cat.id], pageNum(req));
    res.render('list', { title: cat.name, heading: cat.name, sub: cat.description, color: cat.color, kicker: 'Category', ...data, basePath: `/category/${cat.slug}`, metaDesc: cat.description });
  } catch (e) { next(e); }
});

router.get('/author/:id', async (req, res, next) => {
  try {
    const { rows } = await db.q('SELECT id, name, bio FROM users WHERE id=$1', [parseInt(req.params.id, 10) || 0]);
    if (!rows[0]) return next();
    const data = await listArticles('AND a.author_id=$1', [rows[0].id], pageNum(req));
    res.render('list', { title: rows[0].name, heading: rows[0].name, sub: rows[0].bio || `Articles written by ${rows[0].name}.`, kicker: 'Author', color: null, ...data, basePath: `/author/${rows[0].id}` });
  } catch (e) { next(e); }
});

router.get('/search', async (req, res, next) => {
  try {
    const term = String(req.query.q || '').trim().slice(0, 100);
    let data = { articles: [], page: 1, pages: 1, total: 0 };
    if (term) data = await listArticles('AND (a.title ILIKE $1 OR a.content ILIKE $1 OR a.tags ILIKE $1)', [`%${term}%`], pageNum(req));
    res.render('list', { title: `Search: ${term}`, heading: term ? `“${term}”` : 'Search', sub: `${data.total} result${data.total === 1 ? '' : 's'} found`, kicker: 'Search', color: null, ...data, basePath: `/search?q=${encodeURIComponent(term)}&`, robots: 'noindex, follow' });
  } catch (e) { next(e); }
});

router.get('/article/:slug', async (req, res, next) => {
  try {
    const { rows } = await db.q(`${BASE_SELECT.replace('a.views,', 'a.views, a.tags, a.meta_title, a.meta_description, a.updated_at, a.status, a.author_id AS aid, u.bio AS author_bio,')} WHERE a.slug=$1`, [req.params.slug]);
    const a = rows[0];
    if (!a) return next();
    const u = req.user;
    const canPreview = u && (u.role === 'admin' || u.id === a.aid);
    if (a.status !== 'published' && !canPreview) return next();
    if (a.status === 'published') db.q('UPDATE articles SET views=views+1 WHERE id=$1', [a.id]).catch(() => {});
    const related = await db.q(`${BASE_SELECT} WHERE a.status='published' AND a.id<>$1 AND a.category_id IS NOT DISTINCT FROM (SELECT category_id FROM articles WHERE id=$1)
      ORDER BY a.published_at DESC LIMIT 3`, [a.id]);
    res.render('article', { title: a.meta_title || a.title, a, related: related.rows, metaDesc: a.meta_description || a.excerpt, preview: a.status !== 'published' });
  } catch (e) { next(e); }
});

router.get('/media/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!id) return next();
    const { rows } = await db.q('SELECT mime, data FROM media WHERE id=$1', [id]);
    if (!rows[0]) return next();
    res.set('Content-Type', rows[0].mime);
    res.set('Cache-Control', 'public, max-age=31536000, immutable');
    res.send(rows[0].data);
  } catch (e) { next(e); }
});

router.get('/robots.txt', (req, res) => {
  res.type('text/plain').send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /login\nDisallow: /register\n\nSitemap: ${res.locals.siteUrl}/sitemap.xml\n`);
});

router.get('/sitemap.xml', async (req, res, next) => {
  try {
    const base = res.locals.siteUrl;
    const { rows } = await db.q("SELECT slug, updated_at FROM articles WHERE status='published' ORDER BY published_at DESC");
    const urls = [`<url><loc>${base}/</loc><changefreq>daily</changefreq><priority>1.0</priority></url>`]
      .concat(res.locals.categories.map((c) => `<url><loc>${base}/category/${c.slug}</loc><changefreq>daily</changefreq><priority>0.7</priority></url>`))
      .concat(rows.map((r) => `<url><loc>${base}/article/${r.slug}</loc><lastmod>${new Date(r.updated_at).toISOString()}</lastmod><priority>0.8</priority></url>`));
    res.type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join('\n')}\n</urlset>`);
  } catch (e) { next(e); }
});

module.exports = router;
