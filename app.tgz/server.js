const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const compression = require('compression');
const helmet = require('helmet');
const db = require('./db');
const h = require('./lib/helpers');

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('trust proxy', 1);

app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(compression());
app.use(express.urlencoded({ extended: true, limit: '5mb' }));
app.use(express.json({ limit: '5mb' }));
app.use('/static', express.static(path.join(__dirname, 'public'), { maxAge: isProd ? '7d' : 0 }));
app.use('/tinymce', express.static(path.join(__dirname, 'node_modules', 'tinymce'), { maxAge: '30d' }));

app.use(session({
  store: new PgSession({ pool: db.pool, createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 30, httpOnly: true, sameSite: 'lax', secure: isProd },
}));

// Shared locals: settings, user, categories, CSRF token, helpers
app.use(async (req, res, next) => {
  try {
    if (!req.session.csrf) req.session.csrf = crypto.randomBytes(24).toString('hex');
    res.locals.csrf = req.session.csrf;
    res.locals.settings = await db.getSettings();
    res.locals.user = null;
    if (req.session.userId) {
      const { rows } = await db.q('SELECT id, name, email, role, bio FROM users WHERE id=$1', [req.session.userId]);
      res.locals.user = rows[0] || null;
      req.user = rows[0] || null;
    }
    const cats = await db.q(`SELECT c.*, COUNT(a.id) FILTER (WHERE a.status='published')::int AS count
      FROM categories c LEFT JOIN articles a ON a.category_id=c.id GROUP BY c.id ORDER BY c.name`);
    res.locals.categories = cats.rows;
    res.locals.h = h;
    res.locals.path = req.path;
    res.locals.flash = req.session.flash || null;
    delete req.session.flash;
    res.locals.siteUrl = (process.env.SITE_URL || `${req.protocol}://${req.get('host')}`).replace(/\/$/, '');
    next();
  } catch (e) { next(e); }
});

// CSRF check for every state-changing request
app.use((req, res, next) => {
  if (req.method !== 'POST') return next();
  const token = req.get('x-csrf-token') || (req.body && req.body._csrf) || req.query._csrf;
  if (token && token === req.session.csrf) return next();
  return res.status(403).send('Session expired. Please go back, refresh the page and try again.');
});

app.use(require('./routes/auth'));
app.use('/admin', require('./routes/admin'));
app.use(require('./routes/public'));

app.use((req, res) => res.status(404).render('404', { title: 'Page not found' }));
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(err);
  res.status(500).send('Something went wrong. Please try again.');
});

db.init()
  .then(() => app.listen(PORT, () => console.log(`Content Verse running on :${PORT}`)))
  .catch((e) => { console.error('DB init failed', e); process.exit(1); });
